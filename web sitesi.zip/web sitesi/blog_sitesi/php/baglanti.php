<?php
$baglanti=mysqli_connect("localhost","root","","blog_veritabani");
mysqli_query($baglanti,"SET NAMES UTF8");
?> 