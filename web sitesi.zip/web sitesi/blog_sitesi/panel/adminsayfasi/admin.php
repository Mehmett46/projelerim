<?php  session_start(); ?> 
<?php include("../../panel/adminislemleri/vt.php"); 
           $sorgu1 =mysqli_query($baglanti, "SELECT * FROM uye  where  uye_onay='' or uye_onay='0' ");
               $uyesayi=mysqli_num_rows($sorgu1);   
            ?>
<title>ADMİN PANELİ</title>
<link rel="stylesheet" href="../../css/tasarim.css">
<div id="yukari"></div>
<a class="yukaricik" href="#yukari"><img src="../../ikon/ikon.png" title="yukarı"> </a>
<br />


<style>#acmenu{color:red; font-family: sans-serif; font-size: 18px;}
    .num{
        color: red;
        font-weight: bold;
    }
</style>
<div id="ustmenu">
    <div id='cssmenu'>
        <ul>
            <li class='ana' id="genislik"><a href="../../panel/adminsayfasi/admin.php"><span>ANA SAYFA</span></a></li>

            <li class='acilir'><a href='#'><span>İÇERİK</span></a>

                 <ul>

                      <li class='acmenu'><a href="../../panel/adminislemleri/ekle.php"><span>EKLE</span></a> </li>
                     <?php  $yetki=1;
                     
                         if(@$_SESSION['giris']){
                     ?>
                    <li class='acmenu'><a href="../../panel/adminislemleri/sil.php"><span>DÜZENLE</span></a> </li>
                    <li class='acmenu'><a href="../../panel/adminislemleri/sil.php"><span>SİL</span></a> </li>
                 <?php }
                     ?>
                </ul>

            </li>

           
             <li class='acilir'><a href='#'><span>ÜYELER</span></a>

                <ul>
<?php if(@$_SESSION['giris'] ['uye_yetki']=="1"){ ?>
                     <li class='acmenu'><a href="../../panel/adminislemleri/kullaniciekle.php"><span>EKLE</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicisil.php"><span>DÜZENLE</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicisil.php"><span>SİL</span></a> </li>
                   <li class='acmenu'><a href="../adminislemleri/kullanicionay.php"><span>KULLANICI ONAY<?php
                                                if($uyesayi>0){
                                                echo "(<span class='num'>$uyesayi</span>)"; }else{}?></span></a> </li>
         <?php }else{ ?>        
<li class='acmenu' id="acmenu"><?php echo "Bu menüyü kullanabilmeniz için üye yetkiniz olması gerekiyor"; } ?></li>
                </ul>

            </li>
              <li class='acilir'><a href='#'><span>YORUMLAR</span></a>

                <ul>
<?php if(@$_SESSION['giris'] ['uye_yetki']=="1"){ ?>
                     
                    <li class='acmenu'><a href="../adminislemleri/yorumsil.php"><span>SİL</span></a> </li>
                        <?php }else{ ?>        
<li class='acmenu' id="acmenu"><?php echo "Bu menüyü kullanabilmeniz için üye yetkiniz olması gerekiyor"; } ?></li>

                </ul>

            </li>
            <li><a href="../../index.php"><span>SİTEYE GİT</span></a></li>
            <li><a href="../../panel/admingiris/cikis.php"><span>ÇIKIŞ YAP</span></a></li>
            

           


        </ul>
    </div>

</div>
  <div id="logo">
        <div id="sitelogo">
            <img src="../../galeri/Cool%20Text%20-%20--%20Kod%20%20%20%20Dnyam%20--%20%20(1).png">
        </div>
    </div>

    <div class="icarkaplan">
        <div id="icerik">
            <div class="icarkaplan">
               

                <div class="yerles" id="yerlesim">
                    <div class="icarkaplan">
                        <!-- ++++++++++++++++++++++++++++++++++++-->
        
           
                        
 
                        <div style="clear: both"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 