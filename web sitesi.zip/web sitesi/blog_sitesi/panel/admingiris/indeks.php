<style>
    .baslik{
        font-family: sans-serif;
        font-size: 18px;
        color:cyan;
        font-weight: bold;
    }
    .k{
        font-family: sans-serif;
        font-size: 14px;
        color:white;
        font-weight: bold;
    }
    .a{
        font-family: sans-serif;
        font-size: 16px;
        color:red;
        font-weight: bold;
    }
    .y{
          font-family: sans-serif;
        font-size: 16px;
        color:green;
        font-weight: bold;
    }
    .c{
         border: 2px solid red;
            border-radius: 4px;
            margin-bottom: 6px;
            font-weight: bold;
    }
    .b{
        border-radius: 4px; 
    }
    .b:hover{
        border: 2px solid red;
        border-radius: 4px;
    }
</style>
   <?php 
    @session_start();
    if (isset($_SESSION['giris'])) {
        echo "<div class='y'>Giriş yapılıyor.</div><div class='k'> (".$_SESSION['giris']['uye_kullanici'].")</div><br>";
         echo "<div class='k'>4 saniye sonra admin sayfasına yönlendirileceksin</div> <br>";
         header("Refresh: 4; url=../../blog_sitesi/panel/adminsayfasi/admin.php");    
        echo "<a href='../panel/admingiris/cikis.php' class='a'>Çıkış Yap</a>";
    }else {
        echo "<div class='a'>Giriş yapılmamış.</div>";
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PDO | Kayıt  Giriş</title>
</head>
<body>
    <!-- Kayıt Formu -->
    <p class="baslik" >KAYIT İSTEĞİ GÖNDER</p>
    <form action="../panel/admingiris/kayit.php" method="post">
        <label for="" class="k">Kullanıcı Adı</label> <br>
        <input type="text" name="uye_kullanici" class="c"> <br>
        <label for="" class="k">ad soyad</label> <br>
        <input type="text" name="uye_adsoyad" class="c"> <br>
        <label for="" class="k">Mail</label> <br>
        <input type="text" name="uye_email" class="c"> <br>
        <label for="" class="k">Şifre</label> <br>
        <input type="password" name="uye_sifre" class="c"> <br> <br>
        <button class="b">gönder</button>
    </form>
    
    <!-- Giriş Formu -->
    <p class="baslik">ADMİN GİRİŞİ</p>
    <form action="../panel/admingiris/giris.php" method="post">
        <label for="" class="k">Kullanıcı Adı</label> <br>
        <input type="text" name="kullanici" class="c"> <br>
        <label for="" class="k">Şifre</label> <br>
        <input type="password" name="sifre" class="c"> <br><br>
        <button class="b">Giriş Yap</button>
    </form>
</body>
</html>
<?php } ?>