<?php session_start(); ?>
<title>ADMİN PANELİ</title>
<head>
  <style>
    .form{
        width: 200px;
        height: 30px;
        font-family: sans-serif;
        font-size: 18px;
        font-weight: bold;
       
    }
    .formu{
        width: 200px;
        height: 30px;
    }
    .baslik{
        color:aliceblue;
        font-size: 20px;
    }
    .buton{
        width: 100px;
        height: 50px;
    }
    .buton:hover{
        background-color: aqua;
    }
    h2{
        color: #00ff27;
    }
    h3{
        color: red;
        font-size: 22px;
    }
    .ortala{
        margin-left:400px;
        
    }
    </style>
</head>
<link rel="stylesheet" href="../../css/tasarim.css">
<div id="yukari"></div>
<a class="yukaricik" href="#yukari"><img src="../../ikon/ikon.png" title="yukarı"> </a>
<br />


<style>#acmenu{color:red; font-family: sans-serif; font-size: 18px;}</style>
<div id="ustmenu">
    <div id='cssmenu'>
        <ul>
            <li class='ana' id="genislik"><a href="../../panel/adminsayfasi/admin.php"><span>ANA SAYFA</span></a></li>

            <li class='acilir'><a href='#'><span>İÇERİK</span></a>

                 <ul>

                     <li class='acmenu'><a href="../../panel/adminislemleri/ekle.php"><span>EKLE</span></a> </li>
                     <?php  $yetki=1;
                     
                         if($_SESSION['giris']['uye_yetki'] == "1"){
                     ?>
                    <li class='acmenu'><a href="../../panel/adminislemleri/sil.php"><span>DÜZENLE</span></a> </li>
                    <li class='acmenu'><a href="../../panel/adminislemleri/sil.php"><span>SİL</span></a> </li>
                 <?php }
                     ?>
                </ul>

            </li>

           
             <li class='acilir'><a href='#'><span>ÜYELER</span></a>

                <ul>
<?php if($_SESSION['giris'] ['uye_yetki']=="1"){ ?>
                     <li class='acmenu'><a href="../../panel/adminislemleri/kullaniciekle.php"><span>EKLE</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicisil.php"><span>DÜZENLE</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicisil.php"><span>SİL</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicionay.php"><span>KULLANICI ONAY</span></a> </li>
         <?php }else{ ?>        
<li class='acmenu' id="acmenu"><?php echo "Bu menüyü kullanabilmeniz için üye yetkiniz olması gerekiyor"; } ?></li>
                </ul>

            </li>
              <li class='acilir'><a href='#'><span>YORUMLAR</span></a>

                <ul>
<?php if($_SESSION['giris'] ['uye_yetki']=="1"){ ?>
               
                    <li class='acmenu'><a href="../adminislemleri/yorumsil.php"><span>SİL</span></a> </li>
                        <?php }else{ ?>        
<li class='acmenu' id="acmenu"><?php echo "Bu menüyü kullanabilmeniz için üye yetkiniz olması gerekiyor"; } ?></li>

                </ul>

            </li>
            <li><a href="../../index.php"><span>SİTEYE GİT</span></a></li>
            <li><a href="../../panel/admingiris/cikis.php"><span>ÇIKIŞ YAP</span></a></li>
            

           


        </ul>
    </div>

</div>
<div id="logo">
    <div id="sitelogo">
        <img src="../../galeri/Cool%20Text%20-%20--%20Kod%20%20%20%20Dnyam%20--%20%20(1).png">
    </div>
</div>

<div class="icarkaplan">
    <div id="icerik">
        <div class="icarkaplan">


            <div class="yerles" id="yerlesim">
                <div class="icarkaplan">
                    <!-- ++++++++++++++++++++++++++++++++++++-->
                    <?php 
include("vt.php"); 
?>

                    <!doctype html>
                    <html>

                    <head>
                        <meta charset="utf-8">
                        <title>İÇERİK EKLE</title>
                        <link rel="stylesheet" href="adminislemleri/panel.css">
                       
                    </head>

                    <body>
                        <div class="disdiv">
                            <div class="ortadiv">
                              <div class="ortala">
                               <form action="" method="post">
                                <p class="baslik">üye kullanıcı</p>
                                <input type="text" name="uye_kullanici" class="form" placeholder="üye kullanıcı">
                                <p class="baslik">üye şifre</p>
                                <input type="text" name="uye_sifre" class="form" placeholder="üye şifre">
                                <p class="baslik">üye ad soyad</p>
                                <input type="text" name="uye_adsoyad" class="form" placeholder="üye adı soyadı">
                                <p class="baslik">üye email</p>
                                <input type="text" name="uye_email" class="form" placeholder="üye e-mail">
                                <p class="baslik">üye onay</p>
                                <select name="uye_onay" class="formu">
                                <option></option>
                                <option value="1">onayla</option>
                                  <option value="0">onaylama</option>
                                   </select>
                                <p class="baslik">üye yetki</p>
                                <select name="uye_yetki" class="formu">
                                <option></option>
                                <option value="1">yetki ver</option>
                                  <option value="0" >yetki verme</option>
                                   </select><br><br>
                                    <input type="submit" value="kaydet" class="buton">
                                </form>
                               
<?php

$db = new PDO("mysql:host=localhost;dbname=blog_veritabani;charset=utf8", "root", "");

if ($_POST) {
$uye_kullanici = $_POST['uye_kullanici'];
$uye_sifre = $_POST['uye_sifre'];
$uye_adsoyad = $_POST['uye_adsoyad'];                                
$uye_email = $_POST['uye_email'];
$uye_onay = $_POST['uye_onay'];
$uye_yetki = $_POST['uye_yetki'];


if (!$uye_kullanici || !$uye_email || !$uye_sifre) {
    die("<h3>lütfen boş alan bırakmayınız.</h3>");
}

$ekle = $db->prepare("INSERT INTO uye SET uye_kullanici = ?, uye_sifre = ?, uye_adsoyad=?, uye_email = ?, uye_onay=?, uye_yetki=?");
$ekle->execute([$uye_kullanici, $uye_sifre, $uye_adsoyad, $uye_email, $uye_onay, $uye_yetki ]);

if ($ekle) {
    echo "<h2>Kayıt ettiniz</h2>";
}else {
    echo "<h3>Bir hata oluştu.</h3>";
}
}
?>
                                </div>
                            </div>




                        </div>



                        <!-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
                        <div style="clear: both"></div>
                </div>
            </div>
                </div></div>
        </div>
    </div>
</div>
