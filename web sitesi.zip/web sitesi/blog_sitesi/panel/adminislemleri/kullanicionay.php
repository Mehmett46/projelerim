<?php session_start(); ?>
<?php include("../../panel/adminislemleri/vt.php"); 
           $sorgu1 =mysqli_query($baglanti, "SELECT * FROM uye  where  uye_onay='' or uye_onay='0' ");
               $uyesayi=mysqli_num_rows($sorgu1);
         
            ?>
<title>ADMİN PANELİ</title>

<head>
    <style>
        h1 {
            font-family: Arial, sans-serif;
            font-size: 24px;
            color: #ffffff;
        }

        h2 {
            color: #00ff27;
        }

        h3 {
            color: #00ff00;
            font-size: 24px;
            margin-left: 20px;
        }

        .acsec {

            width: 200px;
            height: 30px;
        }

        .eklebuton {
            width: 100px;
            height: 50px;
        }

        #ice {
            height: 200px;
            margin: 10px;
            background-color: #ffffff;
            border: #1bff35 solid 1px;
            border-radius: 8px;
            margin-right: auto;
            margin-left: auto;
            margin: 10px;
            padding: 9px;
            box-shadow: inset 0px 0px 20px #000;
            -webkit-box-shadow: inset 0 0 20px #000;
            overflow: hidden;
        }
        .num{
            color:red;
            font-weight: bold;
        }
    </style>
</head>
<link rel="stylesheet" href="../../css/tasarim.css">
<div id="yukari"></div>
<a class="yukaricik" href="#yukari"><img src="../../ikon/ikon.png" title="yukarı"> </a>
<br />



<style>#acmenu{color:red; font-family: sans-serif; font-size: 18px;}</style>
<div id="ustmenu">
    <div id='cssmenu'>
        <ul>
            <li class='ana' id="genislik"><a href="../../panel/adminsayfasi/admin.php"><span>ANA SAYFA</span></a></li>

            <li class='acilir'><a href='#'><span>İÇERİK</span></a>

                 <ul>

                     <li class='acmenu'><a href="../../panel/adminislemleri/ekle.php"><span>EKLE</span></a> </li>
                     <?php  $yetki=1;
                     
                         if($_SESSION['giris']['uye_yetki'] == "1"){
                     ?>
                    <li class='acmenu'><a href="../../panel/adminislemleri/sil.php"><span>DÜZENLE</span></a> </li>
                    <li class='acmenu'><a href="../../panel/adminislemleri/sil.php"><span>SİL</span></a> </li>
                 <?php }
                     ?>
                </ul>

            </li>
            

           
             <li class='acilir'><a href='#'><span>ÜYELER</span></a>

                <ul>
<?php if($_SESSION['giris'] ['uye_yetki']=="1"){ ?>
                     <li class='acmenu'><a href="../../panel/adminislemleri/kullaniciekle.php"><span>EKLE</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicisil.php"><span>DÜZENLE</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicisil.php"><span>SİL</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicionay.php"><span>KULLANICI ONAY<?php
                                                if($uyesayi>0){
                                                echo "(<span class='num'>$uyesayi</span>)"; }else{}?></span></a> </li>
         <?php }else{ ?>        
<li class='acmenu' id="acmenu"><?php echo "Bu menüyü kullanabilmeniz için üye yetkiniz olması gerekiyor"; } ?></li>
                </ul>

            </li>
              <li class='acilir'><a href='#'><span>YORUMLAR</span></a>

                <ul>
<?php if($_SESSION['giris'] ['uye_yetki']=="1"){ ?>
                    
                    <li class='acmenu'><a href="../adminislemleri/yorumsil.php"><span>SİL</span></a> </li>
                        <?php }else{ ?>        
<li class='acmenu' id="acmenu"><?php echo "Bu menüyü kullanabilmeniz için üye yetkiniz olması gerekiyor"; } ?></li>

                </ul>

            </li>
            <li><a href="../../index.php"><span>SİTEYE GİT</span></a></li>
            <li><a href="../../panel/admingiris/cikis.php"><span>ÇIKIŞ YAP</span></a></li>
            

           


        </ul>
    </div>

</div>
<div id="logo">
    <div id="sitelogo">
        <img src="../../galeri/Cool%20Text%20-%20--%20Kod%20%20%20%20Dnyam%20--%20%20(1).png">
    </div>
</div>


<div id="icerik">






    <div class="icarkaplan">
        <!-- ++++++++++++++++++++++++++++++++++++-->

        <!doctype html>
        <html>

        <head>
            <meta charset="utf-8">
            <title>Veritabanı İşlemleri</title>

            <style>
                .ccc {


                    height: 200px;
                    margin: 10px;
                    background-color: #ffffff;
                    border: #1bff35 solid 1px;
                    border-radius: 8px;
                    margin-right: auto;
                    margin-left: auto;
                    margin: 10px;
                    padding: 9px;
                    box-shadow: inset 0px 0px 20px #000;
                    -webkit-box-shadow: inset 0 0 20px #000;
                    overflow: hidden;
                    font-weight: bold;
                    font-family: sans-serif;
                    font-size: 16px;
                }

                h1 {
                    color: #00ff58;

                    margin-top: 0px;
                    font-size: 50px;
                }

                #sil {

                    margin-top: 0px;
                    float: right;
                    position: absolute;

                }

                .container {
                    margin-top: 100px;
                }

                .onay {
                    font-family: sans-serif;
                    font-size: 22px;
                    color: green;
                }

                .x {
                    color: #ff0000;
                }

                .y {
                    color: #00ff27;
                }

                .a {
                    color: #ff0000;
                }

                .b {
                    color: #00ff27;
                }

            </style>
        </head>


        <body>




            <?php 
include("../../panel/adminislemleri/vt.php"); 
?>










            <?php 
$onay=0;
$sorgu = $baglanti->query("SELECT * FROM uye  where  uye_onay='' or uye_onay='0' or uye_yetki='' or uye_yetki='0' ORDER BY uye_id DESC "); 

while ($sonuc = $sorgu->fetch_assoc()) {
$uye_id = $sonuc['uye_id'];
$uye_kullanici = $sonuc['uye_kullanici'];
$uye_sifre= $sonuc['uye_sifre'];
$uye_adsoyad= $sonuc['uye_adsoyad'];
$uye_email= $sonuc['uye_email'];
$uye_onay= $sonuc['uye_onay'];
$uye_yetki= $sonuc['uye_yetki'];
    
 



?>

            <div class="ccc">

                <div class=""><?php echo "ÜYE  İD=".$uye_id; ?></div>

                <div class=""><?php echo "UYE KULLANICI=".$uye_kullanici; ?></div>
                <div class=""><?php echo "UYE ŞİFRE=".$uye_sifre; ?></div>
                <div class=""><?php echo "UYE ADSOYAD=".$uye_adsoyad; ?></div>
                <div class=""><?php echo "UYE EMAİL=".$uye_email; ?></div>
                <div class=""><?php if($uye_onay==0 or $uye_onay==''){ $uye_onay="onaylanmadı"; echo "UYE ONAY=<span class='x'>$uye_onay</span>"; }
    else{$uye_onay="onaylandı"; echo "UYE ONAY=<span class='y'>$uye_onay</span>";}
            ?></div>

                <div class=""><?php if($uye_yetki==0 or $uye_yetki==''){ $uye_yetki="yetki verilmedi"; echo "UYE YETKİ=<span class='a'>$uye_yetki</span>"; }
    elseif($uye_yetki==1){$uye_yetki="yetki verildi"; echo "UYE YETKİ=<span class='b'>$uye_yetki</span>";}
            ?></div>

                <br><br>
                <?php echo "<div class='onay'>onay bekliyor</div>"; ?>
            </div>

            <div class="duzen"><a href="onay.php?uye_id=<?php echo $uye_id; ?>">
                    <h3>onayla veya yetki ver</h3>
                </a></div>


            <?php 
} 

?>



        </body>

        </html>


        <!-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
        <div style="clear: both"></div>
    </div>
</div>

</div>
</div>
</div>
