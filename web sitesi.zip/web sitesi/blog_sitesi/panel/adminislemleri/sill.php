<?php include("../../panel/adminislemleri/vt.php");  ?>
 <div id="yukari"></div>
<a class="yukaricik" href="#yukari"><img src="../../ikon/ikon.png" title="yukarı"> </a>
<br />
<style>
    .g{
        color: white;
    }
      .x{
        font-size: 60px;
        font-family: sans-serif;
        font-weight: bold;
        margin-left: 300px;
        margin-top: 20px;
          color: green;
    }
</style>
<link rel="stylesheet" href="../../css/tasarim.css">
<div class="sosyal">
    <ul class="ikonlar">
        <li class="ikon" title="facebook"> <a href="http://www.facebook.com"><img src="../../sosyal/facebook.png" /></a></li>
        <li class="ikon" title="twitter"><a href="http://www.twitter.com"><img src="../../sosyal/twitter.png" /></a></li>
        <li class="ikon" title=" instagram"> <a href="http://www.instagram.com"><img src="../../sosyal/instagram.png" /></a></li>
    </ul>
</div>
<div id="ustmenu">
    <div id='cssmenu'>
        <ul>
            <li class='ana' id="genislik"><a href="../index.php"><span>Ana Sayfa</span></a></li>

            <li class='acilir'><a href='#'><span>Kategoriler</span></a>

                <ul>

                     <li class='acmenu'><a href="../sayfalar/php.php"><span>PHP</span></a> </li>
                    <li class='acmenu'><a href="../sayfalar/html.php"><span>HTML</span></a> </li>
                    <li class='acmenu'><a href="../sayfalar/css.php"><span>CSS</span></a> </li>
                    <li class='acmenu'><a href="../sayfalar/csharp.php"><span>C#</span></a> </li>
                    <li class='acmenu'><a href="../sayfalar/java.php"><span>JAVA</span></a> </li>
                    <li class='acmenu'><a href="../sayfalar/python.php"><span>PYTHON</span></a> </li>
                    <li class='acmenu'><a href="../sayfalar/c++.php"><span>C++</span></a> </li>
                    <li class='acmenu'><a href="../sayfalar/javascript.php"><span>JAVASCRİPT</span></a> </li>
                    <li class='acmenu'><a href="../sayfalar/assembly.php"><span>ASSEMBLY</span></a> </li>

                </ul>

            </li>

            <li><a href="../sayfalar/hakkimizda.php"><span>Hakkımızda</span></a></li>
            <li><a href="../sayfalar/iletisim.php"><span>İletişim</span></a></li>
            <li><a href="../sayfalar/yazarlik.php"><span>Yazarlık</span></a></li>

            <li class='kullanici'><a href="../sayfalar/kullanici.php"><span>Kullanıcı Girişi</span></a></li>


        </ul>
    </div>

</div>


 <div id="logo">
        <div id="sitelogo">
            <img src="../../galeri/Cool%20Text%20-%20--%20Kod%20%20%20%20Dnyam%20--%20%20(1).png">
        </div>
    </div>

    <div class="icarkaplan">
        <div id="icerik">
            <div class="icarkaplan">


                <div  id="yerlesim">
                    <div class="icarkaplan">
                        <!-- ++++++++++++++++++++++++++++++++++++-->
  <?php 

                                                

$x=mysqli_query($baglanti, "select * from yorum WHERE yorum_icerik_id=".(int)$_GET['icerik_id']);
                      

                    $y=@mysqli_num_rows($x);
                        
include("vt.php"); 

if($y>0){
if( $baglanti->query("DELETE resim, icerik, yorum FROM icerik INNER JOIN resim ON icerik.icerik_id=resim.icerik_resim_id INNER JOIN yorum ON yorum_icerik_id=icerik_id WHERE icerik_id=".(int)$_GET['icerik_id'])){

  echo "<div class='x'>içerik silindi</div>";
    $_SESSION['baglanti'] = $baglanti;
  
     header("refresh:2; url=sil.php");
}
else{
    echo "<div class='x'>içerik silinemedi</div>";
    header("refresh:2; url=sil.php");
}
    
    
}else{
    if( $baglanti->query("DELETE resim, icerik FROM icerik INNER JOIN resim ON icerik.icerik_id=resim.icerik_resim_id  WHERE icerik_id=".(int)$_GET['icerik_id'])){

  echo "<div class='x'>içerik silindi</div>";
    $_SESSION['baglanti'] = $baglanti;
 
 header("refresh:2; url=sil.php");
}
else{
    echo "<div class='x'>içerik silinemedi</div>";
    header("refresh:2; url=sil.php");
}
}

?>


                        <div style="clear: both"></div>

                    </div>
                </div>
            </div>
        </div>
    </div>
