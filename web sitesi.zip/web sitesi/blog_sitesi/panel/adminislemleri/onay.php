 <?php 
include("vt.php");  
session_start();
?>
<title>ADMİN PANELİ</title>
<head>
   
</head>
<style>
    .form{
        width: 200px;
        height: 30px;
        font-family: sans-serif;
        font-size: 18px;
        font-weight: bold;
       
    }
    .formu{
        width: 980px;
        height: 40px;
    }
    .baslik{
        color:aliceblue;
        font-size: 20px;
    }
    .buton{
        width: 100px;
        height: 50px;
    }
    .buton:hover{
        background-color: aqua;
    }
    h2{
        color: #00ff27;
    }
    h3{
        color: red;
        font-size: 22px;
    }
    .ortala{
        margin-left:400px;
        
    }
    .v{
        margin: 20px;
        color: white;
        font-weight: bold;
    }
    </style>
<link rel="stylesheet" href="../../css/tasarim.css">
<div id="yukari"></div>
<a class="yukaricik" href="#yukari"><img src="../../ikon/ikon.png" title="yukarı"> </a>
<br />



<style>#acmenu{color:red; font-family: sans-serif; font-size: 18px;}</style>
<div id="ustmenu">
    <div id='cssmenu'>
        <ul>
            <li class='ana' id="genislik"><a href="../../panel/adminsayfasi/admin.php"><span>ANA SAYFA</span></a></li>

            <li class='acilir'><a href='#'><span>İÇERİK</span></a>

                 <ul>

                     <li class='acmenu'><a href="../../panel/adminislemleri/ekle.php"><span>EKLE</span></a> </li>
                     <?php  $yetki=1;
                     
                         if($_SESSION['giris']['uye_yetki'] == "1"){
                     ?>
                    <li class='acmenu'><a href="../../panel/adminislemleri/sil.php"><span>DÜZENLE</span></a> </li>
                    <li class='acmenu'><a href="../../panel/adminislemleri/sil.php"><span>SİL</span></a> </li>
                 <?php }
                     ?>
                </ul>

            </li>

           
             <li class='acilir'><a href='#'><span>ÜYELER</span></a>

                <ul>
<?php if($_SESSION['giris'] ['uye_yetki']=="1"){ ?>
                     <li class='acmenu'><a href="../../panel/adminislemleri/kullaniciekle.php"><span>EKLE</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicisil.php"><span>DÜZENLE</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicisil.php"><span>SİL</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicionay.php"><span>KULLANICI ONAY</span></a> </li>
         <?php }else{ ?>        
<li class='acmenu' id="acmenu"><?php echo "Bu menüyü kullanabilmeniz için üye yetkiniz olması gerekiyor"; } ?></li>
                </ul>

            </li>
              <li class='acilir'><a href='#'><span>YORUMLAR</span></a>

                <ul>
<?php if($_SESSION['giris'] ['uye_yetki']=="1"){ ?>
                     
                    <li class='acmenu'><a href="../adminislemleri/yorumsil.php"><span>SİL</span></a> </li>
                        <?php }else{ ?>        
<li class='acmenu' id="acmenu"><?php echo "Bu menüyü kullanabilmeniz için üye yetkiniz olması gerekiyor"; } ?></li>

                </ul>

            </li>
            <li><a href="../../index.php"><span>SİTEYE GİT</span></a></li>
            <li><a href="../../panel/admingiris/cikis.php"><span>ÇIKIŞ YAP</span></a></li>
            

           


        </ul>
    </div>

</div>
<div id="logo">
    <div id="sitelogo">
        <img src="../../galeri/Cool%20Text%20-%20--%20Kod%20%20%20%20Dnyam%20--%20%20(1).png">
    </div>
</div>


    <div id="icerik">
      


            <div class="yerles" id="yerlesim">
                <div class="icarkaplan">
                    <!-- ++++++++++++++++++++++++++++++++++++-->

<?php 

$sorgu = $baglanti->query("SELECT * FROM uye WHERE uye_id =".(int)$_GET['uye_id']); 


$sonuc = $sorgu->fetch_assoc(); 

?>

<div class="ortala">
<div class="col-md-6">

<form action="" method="post">
    
    <div class="tablo">
        
        <div>
           <div class="baslik">uye adı</div>
            <input type="text" name="uye_kullanici" class="form" disabled value="<?php echo $sonuc['uye_kullanici']; 
                  ?>">
            </div>
        </div>

        <form action="" method="post">
        <span class="v">üye onay</span><span class="v">üye yetki</span><br>
    <select name="onay">
       <option value=""></option>
        <option value="1">onayla</option>
         <option value="0">onaylama</option>
    </select>

    <select name="yetki">
       <option value=""></option>
        <option value="1">yetki ver</option>
         <option value="0">yetki verme</option>
    </select>
  <div><input type="submit" class="buton" value="Kaydet"></div>
    </form>

        
     

</form>
</div>
<div>
<?php 

if ($_POST) { 
    
  
    $onay= $_POST['onay'];
    $yetki= $_POST['yetki'];

    
        
      
if ($baglanti->query("UPDATE uye SET uye_onay='$onay', uye_yetki='$yetki' WHERE uye_id =".$_GET['uye_id'])) 
        {
         echo "<h2>değiştirildi</h2>"; 
   
        }
        else
        {
            echo "<h3 class='hata'>Hata oluştu</h3>";
        }
         
 
}

?>
                          
                           
                           
                            </div>




                        </div>



                        <!-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
                        <div style="clear: both"></div>
                </div>
            </div>
                </div>
        
    </div>
</div>
