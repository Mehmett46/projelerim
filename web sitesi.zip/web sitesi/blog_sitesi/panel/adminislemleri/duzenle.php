 <?php 
include("vt.php"); 
  session_start(); 
?>
<title>ADMİN PANELİ</title>
<head>
      <script src="../../sayfalar/bolumler/editor.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>
</head>
<style>
    .form{
        width: 980px;
        height: 200px;
    }
    .formu{
        width: 980px;
        height: 40px;
    }
    .baslik{
        color:aliceblue;
        font-size: 40px;
    }
    .buton{
        width: 100px;
        height: 50px;
    }
    .buton:hover{
        background-color: aqua;
    }
    h2{
        color: #00ff27;
    }
    </style>
<link rel="stylesheet" href="../../css/tasarim.css">
<div id="yukari"></div>
<a class="yukaricik" href="#yukari"><img src="../../ikon/ikon.png" title="yukarı"> </a>
<br />




<style>#acmenu{color:red; font-family: sans-serif; font-size: 18px;}</style>
<div id="ustmenu">
    <div id='cssmenu'>
        <ul>
            <li class='ana' id="genislik"><a href="../../panel/adminsayfasi/admin.php"><span>ANA SAYFA</span></a></li>

            <li class='acilir'><a href='#'><span>İÇERİK</span></a>

                 <ul>

                     <li class='acmenu'><a href="../../panel/adminislemleri/ekle.php"><span>EKLE</span></a> </li>
                     <?php  $yetki=1;
                     
                         if($_SESSION['giris']){
                     ?>
                    <li class='acmenu'><a href="../../panel/adminislemleri/sil.php"><span>DÜZENLE</span></a> </li>
                    <li class='acmenu'><a href="../../panel/adminislemleri/sil.php"><span>SİL</span></a> </li>
                 <?php }
                     ?>
                </ul>

            </li>

           
             <li class='acilir'><a href='#'><span>ÜYELER</span></a>

                <ul>
<?php if($_SESSION['giris'] ['uye_yetki']=="1"){ ?>
                     <li class='acmenu'><a href="../../panel/adminislemleri/kullaniciekle.php"><span>EKLE</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicisil.php"><span>DÜZENLE</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicisil.php"><span>SİL</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicionay.php"><span>KULLANICI ONAY</span></a> </li>
         <?php }else{ ?>        
<li class='acmenu' id="acmenu"><?php echo "Bu menüyü kullanabilmeniz için üye yetkiniz olması gerekiyor"; } ?></li>
                </ul>

            </li>
              <li class='acilir'><a href='#'><span>YORUMLAR</span></a>

                <ul>
<?php if($_SESSION['giris'] ['uye_yetki']=="1"){ ?>
                    
                    <li class='acmenu'><a href="../adminislemleri/yorumsil.php"><span>SİL</span></a> </li>
                        <?php }else{ ?>        
<li class='acmenu' id="acmenu"><?php echo "Bu menüyü kullanabilmeniz için üye yetkiniz olması gerekiyor"; } ?></li>

                </ul>

            </li>
            <li><a href="../../index.php"><span>SİTEYE GİT</span></a></li>
            <li><a href="../../panel/admingiris/cikis.php"><span>ÇIKIŞ YAP</span></a></li>
            

           


        </ul>
    </div>

</div>
<div id="logo">
    <div id="sitelogo">
        <img src="../../galeri/Cool%20Text%20-%20--%20Kod%20%20%20%20Dnyam%20--%20%20(1).png">
    </div>
</div>


    <div id="icerik">
      


            <div class="yerles" id="yerlesim">
                <div class="icarkaplan">
                    <!-- ++++++++++++++++++++++++++++++++++++-->

<?php 

$sorgu = $baglanti->query("SELECT * FROM icerik WHERE icerik_id =".(int)$_GET['icerik_id']); 


$sonuc = $sorgu->fetch_assoc(); 

?>

<div class="container">
<div class="col-md-6">

<form action="" method="post">
    
    <div class="tablo">
        
        <div>
           <div class="baslik">İÇERİK BAŞLIK</div>
            <input type="text" name="icerik_baslik" class="formu" value="<?php echo $sonuc['icerik_baslik']; 
                  ?>">
            </div>
        </div>

        <div>
            <div class="baslik">İÇERİK AÇIKLAMA</div>
            <textarea name="icerik_aciklama" class="form"><?php echo $sonuc['icerik_aciklama']; ?></textarea>
        </div>
         <div>
            <div class="baslik">İÇERİK DETAY</div>
            <textarea name="icerik_detay" class="form"><?php echo $sonuc['icerik_detay']; ?></textarea>
        </div>

        <div>
          
            <div><input type="submit" class="buton" value="Kaydet"></div>
        </div>

    

</form>
</div>
<div>
<?php   

if ($_POST) { 
    
    $icerik_baslik = $_POST['icerik_baslik'];
    $icerik_aciklama = $_POST['icerik_aciklama'];
     $icerik_detay= $_POST['icerik_detay'];

    if ($icerik_baslik<>"" && $icerik_aciklama<>"" && $icerik_detay<>"") {  
        
      
        if ($baglanti->query("UPDATE icerik SET icerik_baslik = '$icerik_baslik', icerik_aciklama = '$icerik_aciklama', icerik_detay = '$icerik_detay' WHERE icerik_id =".$_GET['icerik_id'])) 
        {
         echo "<h2>içerik değiştirildi</h2>"; 
        }
        else
        {
            echo "Hata oluştu";
        }
         
    }
}
?>
                          
                           
                           
                            </div>




                        </div>



                        <!-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
                        <div style="clear: both"></div>
                </div>
            </div>
                </div>
        
    </div>
</div>
