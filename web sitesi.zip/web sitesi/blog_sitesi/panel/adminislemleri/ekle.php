                     <?php 
include("vt.php"); 
 session_start();
?>
<title>ADMİN PANELİ</title>
<head>

    <script src="../../sayfalar/bolumler/editor.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>
  
   
    <style>
        
        h1{
            font-family: Arial, sans-serif;
	font-size: 24px;
	color: #ffffff;
        }
        h2{
            color: #00ff27;
        }
        h3{
            color: #ff0000;
            font-size: 24px;
        }
        .acsec{
            
            width: 200px;
            height: 30px;
        }
        .eklebuton{
            width: 100px;
            height: 50px;
        }
        .baslik{
width: 300px;
           margin-left: 350px; 
            font-size: 23px;
            height: 30px;
              border: 2px solid red;
            border-radius: 4px;
            margin-bottom: 6px;
        }
        .aciklama{
            width: 980px;
            height: 200px;
            font-size: 20px;
              border: 2px solid red;
            border-radius: 4px;
            margin-bottom: 6px;
            
            
        }
        .detay{
            width: 980px;
            height: 200px;
            font-size: 23px;
        }
        .resim{
            font-size: 25px;
            font-family: sans-serif;
            margin-left: 425px;
            color: green;
        }
        .dosya{
            font-size: 20px;
            font-family: sans-serif;
            margin-left: 350px;
            color: aqua;
        }
        .d{
              font-size: 20px;
            font-family: sans-serif;
            margin-left: 350px;
            color: aqua;
        }
        .e{
             font-size: 20px;
            font-family: sans-serif;
            margin-left:350px;
            color: aqua;
        }
         .f{
              font-size: 20px;
            font-family: sans-serif;
            margin-left: 350px;
            color:red;
        }
        .g{
             font-size: 20px;
            font-family: sans-serif;
            margin-left:350px;
            color:red;
        }
    </style>
</head>
<link rel="stylesheet" href="../../css/tasarim.css">
<div id="yukari"></div>
<a class="yukaricik" href="#yukari"><img src="../../ikon/ikon.png" title="yukarı"> </a>
<br />



<style>#acmenu{color:red; font-family: sans-serif; font-size: 18px;}</style>
<div id="ustmenu">
    <div id='cssmenu'>
        <ul>
            <li class='ana' id="genislik"><a href="../../panel/adminsayfasi/admin.php"><span>ANA SAYFA</span></a></li>

            <li class='acilir'><a href='#'><span>İÇERİK</span></a>

                 <ul>

                     <li class='acmenu'><a href="../../panel/adminislemleri/ekle.php"><span>EKLE</span></a> </li>
                     <?php  $yetki=1;
                      
                          if($_SESSION['giris']){
                     ?>
                    <li class='acmenu'><a href="../../panel/adminislemleri/sil.php"><span>DÜZENLE</span></a> </li>
                    <li class='acmenu'><a href="../../panel/adminislemleri/sil.php"><span>SİL</span></a> </li>
                 <?php }
                     ?>
                </ul>

            </li>

           
             <li class='acilir'><a href='#'><span>ÜYELER</span></a>

                <ul>
<?php if($_SESSION['giris'] ['uye_yetki']=="1"){ ?>
                     <li class='acmenu'><a href="../../panel/adminislemleri/kullaniciekle.php"><span>EKLE</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicisil.php"><span>DÜZENLE</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicisil.php"><span>SİL</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicionay.php"><span>KULLANICI ONAY</span></a> </li>
         <?php }else{ ?>        
<li class='acmenu' id="acmenu"><?php echo "Bu menüyü kullanabilmeniz için üye yetkiniz olması gerekiyor"; } ?></li>
                </ul>

            </li>
              <li class='acilir'><a href='#'><span>YORUMLAR</span></a>

                <ul>
<?php if($_SESSION['giris'] ['uye_yetki']=="1"){ ?>
                   
                    <li class='acmenu'><a href="../adminislemleri/yorumsil.php"><span>SİL</span></a> </li>
                        <?php }else{ ?>        
<li class='acmenu' id="acmenu"><?php echo "Bu menüyü kullanabilmeniz için üye yetkiniz olması gerekiyor"; } ?></li>

                </ul>

            </li>
            <li><a href="../../index.php"><span>SİTEYE GİT</span></a></li>
            <li><a href="../../panel/admingiris/cikis.php"><span>ÇIKIŞ YAP</span></a></li>
            

           


        </ul>
    </div>

</div>
<div id="logo">
    <div id="sitelogo">
        <img src="../../galeri/Cool%20Text%20-%20--%20Kod%20%20%20%20Dnyam%20--%20%20(1).png">
    </div>
</div>

<div class="icarkaplan">
    <div id="icerik">
        <div class="icarkaplan">


            <div  id="yerlesim">
                <div class="icarkaplan">
                    <!-- ++++++++++++++++++++++++++++++++++++-->


                    <!doctype html>
                    <html>

                    <head>
                        <meta charset="utf-8">
       
                        <title>İÇERİK EKLE</title>
                        <link rel="stylesheet" href="../panel/adminislemleri/panel.css">
                       
                    </head>

                    <body>
                        <div class="disdiv">
                            <div class="ortadiv">
                                <div class="tablo" align="left">
                                     

                                   <!--++++++++++++++++++++++++++++++++++++++++++++-->
<a class="resim" href="resimekle.php" title="tıkla">[Resim Ekle]</a><br>
                                  
                                       
                                       <?php
$sorgu=mysqli_connect("localhost","root","","blog_veritabani");
mysqli_query($sorgu, "SET NAMES UTF8");
     $sorgu1 = $sorgu->query("SELECT * FROM icerik ORDER BY icerik_id DESC"); 
                                    while($islem=mysqli_fetch_array($sorgu1)){ 
                                        @$i++;
                                                                              if($i==1){
                                                                                  $t=$islem['icerik_id'];
                                                                                  
 }
                                   }
if(isset($_POST)){//Form gönderildi mi?
if
(@$_FILES["resim"]["size"]<1024*1024){//Dosya boyutu 1Mb
//tan az olsun

if
    
(@$_FILES["resim"]["type"]=="image/jpeg"){//dosya
//tipi jpeg olsun
$acikla=$_POST["acikla"];
$dosya_adi=$_FILES["resim"]["name"];
//Dosyaya yeni bir isim oluşturuluyor
$uret=array("as","rt","ty","yu","fg");

$uzanti=substr($dosya_adi,-4,4);
$sayi_tut=rand(1,10000);
$yeni_ad="../../../dosyalar/".$uret[rand(0,4)].$sayi_tut.$uzanti;

if
(move_uploaded_file($_FILES["resim"]["tmp_name"],$yeni_ad)){
echo '<div class="d">Dosya başarıyla yüklendi.</div>';
//Bilgiler veri tabanına kaydedilsin
$t+=1;
$sorgu->query("insert into resim
(resim_link, resim_baslik, icerik_resim_id) values ('$yeni_ad','$acikla', '$t')");
 
if ($sorgu){
echo '<div class="e">Veritabanına kaydedildi.</div>';
   
}else{
echo '<div class="f">Kayıt sırasında hata oluştu!</div>';
}
}else{
echo '<div class="g">Dosya Yüklenemedi!</div>';
}
}else{
echo '<div class="dosya">Dosya yalnızca jpeg formatında olabilir!</div>';
}
}else{
echo 'Dosya boyutu 1 Mb ı geçemez!';
}
}
?>
                                        <!--+++++++++++++++++++++++++++-->
                                         <form action="" method="post">
                                          <div align="center"> <h1> İÇERİK BAŞLIK</h1></div>
                                         <input type="text" name="icerik_baslik" class="baslik" value="<?php
                                            if(isset($_POST)){ 
                                           echo @$acikla; }?>" placeholder="önce resim ekleyin...">
                                      
                                       <div align="center"> <h1> İÇERİK AÇIKLAMA</h1></div>
                                       
                                      <textarea name="icerik_aciklama" class="aciklama" ></textarea>
                                      <div align="center"> <h1> İÇERİK DETAY</h1></div>
                                        <textarea name="icerik_detay" class="detay"></textarea>
                                       
                                        <div align="center">
                                        <h1>İÇERİK KATEGORİ</h1><select name="icerik_kategori_id" class="acsec">

                                            <option value="">seç</option>

                                            <option value="1">PHP</option>
                                            <option value="2">HTML</option>
                                            <option value="3">CSS</option>
                                            <option value="4">C#</option>
                                            <option value="5">JAVA</option>
                                            <option value="6">PHYTON</option>
                                            <option value="7">C++</option>
                                            <option value="8">JAVASCRİPT</option>
                                            <option value="9">ASSEMBLY</option>
                                        </select> <br>


                                        <input class="eklebuton" type="submit" value="Ekle">
                                        <input class="eklebuton" type="reset" value="Temizle">
                                        </div>
                                         </form>
                                          
       
                                </div>


                                <?php
                              
if(isset($_SESSION['giris']['uye_kullanici'])){
    $uye_ad=$_SESSION['giris']['uye_kullanici'];
}
if ($_POST) {
 
    
    @$icerik_baslik = addslashes($_POST['icerik_baslik']); 
    @$icerik_aciklama = addslashes($_POST['icerik_aciklama']);
    @$icerik_detay =addslashes( $_POST['icerik_detay']);
    @$icerik_kategori_id = $_POST['icerik_kategori_id'];
    
    if ($icerik_baslik<>"" && $icerik_baslik<>""  && $icerik_kategori_id!=0 ) { 
    
         
        $sql="INSERT INTO icerik (icerik_baslik, icerik_aciklama, icerik_detay, icerik_kategori_id, uye_adsoyad) VALUES ('$icerik_baslik','$icerik_aciklama', '$icerik_detay', '$icerik_kategori_id', '$uye_ad')";
       
        if ($baglanti->query($sql)) 
        {
            echo "<div align='center'><h2>Veri Eklendi</h2></div>"; 
        }
        else
        {
            echo "<div align='center'><h3>Hata oluştu</h3></div>";
        }

    }
    else{
        echo "<div align='center'><h3>Alanları Boş geçmeyin</h3></div>";
    }

}
                                

?>
                            </div>




                        </div>



                        <!-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
                        <div style="clear: both"></div>
               
                

