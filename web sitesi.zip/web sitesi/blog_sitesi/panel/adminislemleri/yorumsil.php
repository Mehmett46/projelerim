<?php session_start(); ?>
<title>ADMİN PANELİ</title>
<head> 
    <style>
        h1{
            font-family: Arial, sans-serif;
	font-size: 24px;
	color: #ffffff;
        }
        h2{
            color: #00ff27;
        }
        h3{
            color: #ff0000;
            font-size: 24px;
        }
        .acsec{
            
            width: 200px;
            height: 30px;
        }
        .eklebuton{
            width: 100px;
            height: 50px;
        }
          #ice{
       
       
         height: 200px;
    margin: 10px;
    background-color: #ffffff;
    border: #1bff35 solid 1px;
    border-radius: 8px;
    margin-right: auto;
    margin-left: auto;
    margin: 10px;
    padding: 9px;
    box-shadow: inset 0px 0px 20px #000;
    -webkit-box-shadow: inset 0 0 20px #000;
    overflow: hidden;
    }
    </style>
</head>
<link rel="stylesheet" href="../../css/tasarim.css">
<div id="yukari"></div>
<a class="yukaricik" href="#yukari"><img src="../../ikon/ikon.png" title="yukarı"> </a>
<br />



<style>#acmenu{color:red; font-family: sans-serif; font-size: 18px;}</style>
<div id="ustmenu">
    <div id='cssmenu'>
        <ul>
            <li class='ana' id="genislik"><a href="../../panel/adminsayfasi/admin.php"><span>ANA SAYFA</span></a></li>

            <li class='acilir'><a href='#'><span>İÇERİK</span></a>

                 <ul>

                     <li class='acmenu'><a href="../../panel/adminislemleri/ekle.php"><span>EKLE</span></a> </li>
                     <?php  $yetki=1;
                     
                         if($_SESSION['giris']['uye_yetki'] == "1"){
                     ?>
                    <li class='acmenu'><a href="../../panel/adminislemleri/sil.php"><span>DÜZENLE</span></a> </li>
                    <li class='acmenu'><a href="../../panel/adminislemleri/sil.php"><span>SİL</span></a> </li>
                 <?php }
                     ?>
                </ul>

            </li>

           
             <li class='acilir'><a href='#'><span>ÜYELER</span></a>

                <ul>
<?php if($_SESSION['giris'] ['uye_yetki']=="1"){ ?>
                     <li class='acmenu'><a href="../../panel/adminislemleri/kullaniciekle.php"><span>EKLE</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicisil.php"><span>DÜZENLE</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicisil.php"><span>SİL</span></a> </li>
                    <li class='acmenu'><a href="../adminislemleri/kullanicionay.php"><span>KULLANICI ONAY</span></a> </li>
         <?php }else{ ?>        
<li class='acmenu' id="acmenu"><?php echo "Bu menüyü kullanabilmeniz için üye yetkiniz olması gerekiyor"; } ?></li>
                </ul>

            </li>
              <li class='acilir'><a href='#'><span>YORUMLAR</span></a>

                <ul>
<?php if($_SESSION['giris'] ['uye_yetki']=="1"){ ?>
                   
                    <li class='acmenu'><a href="../adminislemleri/yorumsil.php"><span>SİL</span></a> </li>
                        <?php }else{ ?>        
<li class='acmenu' id="acmenu"><?php echo "Bu menüyü kullanabilmeniz için üye yetkiniz olması gerekiyor"; } ?></li>

                </ul>

            </li>
            <li><a href="../../index.php"><span>SİTEYE GİT</span></a></li>
            <li><a href="../../panel/admingiris/cikis.php"><span>ÇIKIŞ YAP</span></a></li>
            

           


        </ul>
    </div>

</div>
<div id="logo">
    <div id="sitelogo">
        <img src="../../galeri/Cool%20Text%20-%20--%20Kod%20%20%20%20Dnyam%20--%20%20(1).png">
    </div>
</div>


    <div id="icerik">
        <div class="icarkaplan">


             <div id="yerlesim">
        <?php 
include("vt.php"); 
if($_GET){
if ($baglanti->query("DELETE FROM yorum WHERE yorum_id =".(int)$_GET['yorum_id'])){ 
echo "<div class='silik' id='ice'><h1>YORUM SİLİNDİ</h1></div><br>";
}
    else{
    echo "<div class='silik' id='ice'><h1>YORUM SİLİNEMEDİ</h1></div>"; }
}
     
      
?>      

                <div class="icarkaplan">
                    <!-- ++++++++++++++++++++++++++++++++++++-->

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Veritabanı İşlemleri</title>

 <style>
       .ccc{
       
       
         height: 200px;
    margin: 10px;
    background-color: #ffffff;
    border: #1bff35 solid 1px;
    border-radius: 8px;
    margin-right: auto;
    margin-left: auto;
    margin: 10px;
    padding: 9px;
    box-shadow: inset 0px 0px 20px #000;
    -webkit-box-shadow: inset 0 0 20px #000;
    overflow: hidden;
    }
    h1{
        color: #00ff58;
        
        margin-top: 0px;
        font-size: 50px;
    }
    #sil{
        
        margin-top: 0px;
       float: right;
         position:absolute;
        
    }
    .container{
        margin-top: 100px;
    }
   
    </style>
</head>

  
<body>

<div class="container" >


  <?php 
 
?>
</div>


<?php 

$sorgu = $baglanti->query("SELECT * FROM yorum"); 

while ($sonuc = $sorgu->fetch_assoc()) { 
$uye_adsoyad = $sonuc['uye_adsoyad'];
$yorum_icerik= $sonuc['yorum_icerik'];
    $yorum_id=$sonuc['yorum_id'];
    $yorum_tarih=$sonuc['yorum_tarih'];
 


?>
  
    <div class="ccc"> 
       <div class=""><?php echo "YORUM İD=".$yorum_id; ?></div>
       <div class=""><?php echo "ÜYE AD SOYAD=".$uye_adsoyad; ?></div>
  <div class=""><?php echo "ÜYE YORUMU=".$yorum_icerik; ?></div>
   <div class=""><?php echo "YORUM TARİHİ=".$yorum_tarih; ?></div>
    </div>
    <div class="duzen"><a href="yorumsil.php?yorum_id=<?php echo $yorum_id; ?>" ><h3>Sil</h3></a></div>
     
<?php 
} 

?>
 


    
</body>
</html>


                        <!-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
                        <div style="clear: both"></div>
                </div>
            </div>
                </div></div>
        </div>
    </div>
</div>
