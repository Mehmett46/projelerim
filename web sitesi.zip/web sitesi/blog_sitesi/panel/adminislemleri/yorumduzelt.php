<?php include("vt.php"); ?>

<div id="yukari"></div>
<a class="yukaricik" href="#yukari"><img src="../../ikon/ikon.png" title="yukarı"> </a>
<br />
<style>
    .g {
        color: white;
    }

    .form {
        margin-left: 300px;
        margin-top: 8px;

    }

    .formu {
        border-radius: 6px;
        border: 2px solid red;
        font-weight: bold;
        font-size: 15px;
        text-align: center;
    }

    .icerik {
        width: 320px;
        height: 60px;
        margin-top: 6px;
        border-radius: 8px;
        border: 2px solid red;
        font-weight: 600;
        font-family: sans-serif;
        font-size: 14px;
    }

    .buton {
        width: 80px;
        margin-top: 5px;
        font-size: 18px;
        font-weight: bold;
        border: 2px solid red;
        border-radius: 4px;
    }

    .buton:hover {
        color: green;
        border: 2px solid green;
    }

</style>
<link rel="stylesheet" href="../../css/tasarim.css">
<div class="sosyal">
    <ul class="ikonlar">
        <li class="ikon" title="facebook"> <a href="http://www.facebook.com"><img src="../../sosyal/facebook.png" /></a></li>
        <li class="ikon" title="twitter"><a href="http://www.twitter.com"><img src="../../sosyal/twitter.png" /></a></li>
        <li class="ikon" title=" instagram"> <a href="http://www.instagram.com"><img src="../../sosyal/instagram.png" /></a></li>
    </ul>
</div>
<div id="ustmenu">
    <div id='cssmenu'>
        <ul>
            <li class='ana' id="genislik"><a href="../../index.php"><span>Ana Sayfa</span></a></li>

            <li class='acilir'><a href='#'><span>Kategoriler</span></a>

                <ul>

                    <li class='acmenu'><a href="../../sayfalar/php.php"><span>PHP</span></a> </li>
                    <li class='acmenu'><a href="../../sayfalar/html.php"><span>HTML</span></a> </li>
                    <li class='acmenu'><a href="../../sayfalar/css.php"><span>CSS</span></a> </li>
                    <li class='acmenu'><a href="../../sayfalar/csharp.php"><span>C#</span></a> </li>
                    <li class='acmenu'><a href="../../sayfalar/java.php"><span>JAVA</span></a> </li>
                    <li class='acmenu'><a href="../../sayfalar/python.php"><span>PYTHON</span></a> </li>
                    <li class='acmenu'><a href="../../sayfalar/c++.php"><span>C++</span></a> </li>
                    <li class='acmenu'><a href="../../sayfalar/javascript.php"><span>JAVASCRİPT</span></a> </li>
                    <li class='acmenu'><a href="../../sayfalar/assembly.php"><span>ASSEMBLY</span></a> </li>

                </ul>

            </li>

            <li><a href="../../sayfalar/hakkimizda.php"><span>Hakkımızda</span></a></li>
            <li><a href="../../sayfalar/iletisim.php"><span>İletişim</span></a></li>
            <li><a href="../../sayfalar/yazarlik.php"><span>Yazarlık</span></a></li>

            <li class='kullanici'><a href="../../sayfalar/kullanici.php"><span>Kullanıcı Girişi</span></a></li>


        </ul>
    </div>

</div>


<div id="logo">
    <div id="sitelogo">
        <img src="../../galeri/Cool%20Text%20-%20--%20Kod%20%20%20%20Dnyam%20--%20%20(1).png">
    </div>
</div>

<div class="icarkaplan">
    <div id="icerik">
        <div class="icarkaplan">


            <div id="yerlesim">
                <div class="icarkaplan">
                    <?php
                       

$sorgu = $baglanti->query("SELECT * FROM yorum WHERE yorum_id =".(int)$_GET['yorum_id']); 

echo date("d.m.Y");
$sonuc = $sorgu->fetch_assoc(); 
                    
if ($_POST) { 
    
    $yorum_icerik = $_POST['yorum_icerik'];
  $degisiklik=1;

    if ($yorum_icerik<>"" ) {  
        
      
        if ($baglanti->query("UPDATE yorum SET yorum_icerik = '$yorum_icerik', yorum_degistirme='$degisiklik' WHERE yorum_id =".$_GET['yorum_id'])) 
        {
            $gonder=$sonuc['yorum_icerik_id'];
          header("Location: ../../sayfalar/yonlendirme.php?icerik_id=$gonder");
        }
        else
        {
            echo "Hata oluştu";
        }
         
    }
}
?>

                    <div class="form">
                        <form action="" method="post">



                            <div>

                                <input type="text" name="uye_adsoyad" class="formu" value="<?php echo $sonuc['uye_adsoyad']; ?>" disabled>
                            </div>


                            <div>

                                <textarea name="yorum_icerik" class="icerik"><?php echo $sonuc['yorum_icerik'];  ?></textarea>
                            </div>


                            <div>

                                <div><input type="submit" class="buton" value="Kaydet"></div>
                            </div>

                        </form>
                    </div>



                    <div style="clear: both"></div>

                </div>
            </div>
        </div>
    </div>
</div>
