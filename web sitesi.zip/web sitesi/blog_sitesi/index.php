
<?php include "php/baglanti.php";  ?>
<?php
 session_start();
  
$kayitlar=mysqli_query($baglanti, "select * from icerik  ORDER BY icerik_id DESC");

?>
<!DOCTYPE html>
<meta charset="utf-8">
<html>

<head>
    <title>KOD DÜNYAM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/tasarim.css">


</head>
<style>
    #kutu{display:inline; font-family: sans-serif;}
    #input{border: 1px solid #ff0606; font-size: 15px; font-weight: bold; font-family: sans-serif; }
    .orneklink{
        text-decoration: none;
    }
  
    </style>
<body>
    <div id="yukari"></div>
    <a class="yukaricik" href="#yukari"><img src="ikon/ikon.png" title="yukarı"> </a>
    <br />

    <div id="ara" align="center">
        <form action="arama.php" id="kutu" method="get" >
<input type="text"  name="aramasorgusu" size="30"   placeholder="ne aramıştınız..." value=""  class="z"/>
            <input id="buton" style="background: border: 1px;  font-weight: bold;" type="submit" value="ara" />
        </form>

    </div>
    <div class="sosyal">
        <ul class="ikonlar">
            <li class="ikon" title="facebook"> <a href="http://www.facebook.com"><img src="sosyal/facebook.png" /></a></li>
            <li class="ikon" title="twitter"><a href="http://www.twitter.com"><img src="sosyal/twitter.png" /></a></li>
            <li class="ikon" title=" instagram"> <a href="http://www.instagram.com"><img src="sosyal/instagram.png" /></a></li>
        </ul>
    </div>
    <div id="ustmenu">
        <div id='cssmenu'>
            <ul>
                <li class='ana' id="genislik"><a href="index.php"><span>Ana Sayfa</span></a></li>

                <li class='acilir'><a href='#'><span>Kategoriler</span></a>

                    <ul>

                        <li class='acmenu'><a href="sayfalar/php.php"><span>PHP</span></a> </li>
                        <li class='acmenu'><a href="sayfalar/html.php"><span>HTML</span></a> </li>
                        <li class='acmenu'><a href="sayfalar/css.php"><span>CSS</span></a> </li>
                        <li class='acmenu'><a href="sayfalar/csharp.php"><span>C#</span></a> </li>
                        <li class='acmenu'><a href="sayfalar/java.php"><span>JAVA</span></a> </li>
                        <li class='acmenu'><a href="sayfalar/python.php"><span>PYTHON</span></a> </li>
                        <li class='acmenu'><a href="sayfalar/c++.php"><span>C++</span></a> </li>
                        <li class='acmenu'><a href="sayfalar/javascript.php"><span>JAVASCRİPT</span></a> </li>
                        <li class='acmenu'><a href="sayfalar/assembly.php"><span>ASSEMBLY</span></a> </li>

                    </ul>

                </li>

                <li><a href="../blog_sitesi/sayfalar/hakkimizda.php"><span>Hakkımızda</span></a></li>
                <li><a href="../blog_sitesi/sayfalar/iletisim.php"><span>İletişim</span></a></li>
                <li><a href="../blog_sitesi/sayfalar/yazarlik.php"><span>Yazarlık</span></a></li>
<?php if(@$_SESSION['giris']){ ?>
                <li class='kullanici'><a href="../blog_sitesi/panel/admingiris/cikis.php"><span>Çıkış Yap</span></a></li>
                <li class='kullanici'><a href="../blog_sitesi/panel/adminsayfasi/admin.php"><span>Cpanel</span></a></li>
                <?php }else{ ?>
                <li class='kullanici'><a href="../blog_sitesi/sayfalar/kullanici.php"><span>Giriş Yap</span></a></li>
                    <?php } ?>

            </ul>
        </div>

    </div>
    <div id="logo">
        <div id="sitelogo">
            <img src="galeri/Cool%20Text%20-%20--%20Kod%20%20%20%20Dnyam%20--%20%20(1).png">
        </div>
    </div>

    <div class="icarkaplan">
        <div id="icerik">
            <div class="icarkaplan">


                <div class="yerles" id="yerlesim">
                    <div class="icarkaplan">
                        <!-- ++++++++++++++++++++++++++++++++++++-->
                        <?php 
                        $i=0;
                        while($kayit=mysqli_fetch_array($kayitlar)){$i++; ?>
             <div class="div" title="">                                          
<?php
    if($i%8==0){                                         
 ?>
                              <img src="https://img.webme.com/pic/p/piriketseverler/reklamalani7.gif" width="450" height="100"> <?php }else{?>
                                
                        <a href="sayfalar/yonlendirme.php?icerik_id=<?php echo $kayit['icerik_id']; ?>" title="devamını oku" class="orneklink">
                         
 


                                <span>
                                    <h2 id="h2"><?php echo $kayit['icerik_baslik']; ?></h2>
                                </span><br>

                                <span id="yazi">
                                    <?php                                                               
echo $kayit['icerik_aciklama'];
?>
                                    <!-- ++++++++++++++++++++++++++++-->
                                </span>
                                <span id="yazi"><br><br>
                                    <?php                                                               
echo $kayit['icerik_detay']; }
?>
                                    <!-- ++++++++++++++++++++++++++++-->
                                </span>

                            </div>
                        </a>
                        <?php  }?>



                        <div style="clear: both"></div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <a class="yukaricik" href="#yukari"><img src="ikon/ikon.png"> </a>
