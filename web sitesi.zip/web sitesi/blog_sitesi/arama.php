<?php include "php/baglanti.php";  ?>


<?php session_start();
$aramasorgusu = ($_GET['aramasorgusu']);
$aramasorgusu=mb_strtolower($aramasorgusu);
$sonucsorgu = @mysqli_query($baglanti, "SELECT * FROM icerik  WHERE icerik_baslik  LIKE '%".$aramasorgusu."%' or '".$aramasorgusu."%' or '%\_".$aramasorgusu."%' or '%".$aramasorgusu."' " );

?>



<!DOCTYPE html>
<meta charset="utf-8">
<html>

<head>
    <title>KOD DÜNYAM</title>
    <link rel="stylesheet" href="css/tasarim.css">


</head>
<style>
    #kutu{display:inline; font-family: sans-serif;}
    #input{border: 1px solid #ff0606; font-size: 15px; font-weight: bold; font-family: sans-serif; }
    #aramaerror{
        
    }
    .arama{float: left;

    width: 940px;
    height: 240px;
    margin: 10px;
    background-color: #ffffff;
    border: #1bff35 solid 1px;
    border-radius: 8px;
    margin-right: auto;
    margin-left: auto;
    margin: 10px;
    padding: 9px;
    box-shadow: inset 0px 0px 20px #000;
    -webkit-box-shadow: inset 0 0 20px #000;
    overflow: hidden;}
    .a{
        font-family: sans-serif;
        font-size: 35px;
        font-weight: bold;
    }
    .b{
         font-family: sans-serif;
        font-size: 26px;
    
        font-weight:bold;
    }
    .c{
    font-family: sans-serif;
        font-size: 18px;
        color: green;
        font-weight:bold;
    }
    </style>
<body>
    <div id="yukari"></div>
    <a class="yukaricik" href="#yukari"><img src="ikon/ikon.png" title="yukarı"> </a>
    <br />

    <div id="ara" align="center">
        <form action="arama.php" id="kutu" method="get" >
<input type="text"  name="aramasorgusu" size="30"   placeholder="ne aramıştınız..." value="" />
            <input id="buton" style="background: border: 1px;  font-weight: bold;" type="submit" value="ara" />
        </form>

    </div>
    <div class="sosyal">
        <ul class="ikonlar">
            <li class="ikon" title="facebook"> <a href="http://www.facebook.com"><img src="sosyal/facebook.png" /></a></li>
            <li class="ikon" title="twitter"><a href="http://www.twitter.com"><img src="sosyal/twitter.png" /></a></li>
            <li class="ikon" title=" instagram"> <a href="http://www.instagram.com"><img src="sosyal/instagram.png" /></a></li>
        </ul>
    </div>
    <div id="ustmenu">
        <div id='cssmenu'>
            <ul>
                <li class='ana' id="genislik"><a href="index.php"><span>Ana Sayfa</span></a></li>

                <li class='acilir'><a href='#'><span>Kategoriler</span></a>

                    <ul>

                        <li class='acmenu'><a href="sayfalar/php.php"><span>PHP</span></a> </li>
                        <li class='acmenu'><a href="sayfalar/html.php"><span>HTML</span></a> </li>
                        <li class='acmenu'><a href="sayfalar/css.php"><span>CSS</span></a> </li>
                        <li class='acmenu'><a href="sayfalar/csharp.php"><span>C#</span></a> </li>
                        <li class='acmenu'><a href="sayfalar/java.php"><span>JAVA</span></a> </li>
                        <li class='acmenu'><a href="sayfalar/python.php"><span>PYTHON</span></a> </li>
                        <li class='acmenu'><a href="sayfalar/c++.php"><span>C++</span></a> </li>
                        <li class='acmenu'><a href="sayfalar/javascript.php"><span>JAVASCRİPT</span></a> </li>
                        <li class='acmenu'><a href="sayfalar/assembly.php"><span>ASSEMBLY</span></a> </li>

                    </ul>

                </li>

                <li><a href="../blog_sitesi/sayfalar/hakkimizda.php"><span>Hakkımızda</span></a></li>
                <li><a href="../blog_sitesi/sayfalar/iletisim.php"><span>İletişim</span></a></li>
                <li><a href="../blog_sitesi/sayfalar/yazarlik.php"><span>Yazarlık</span></a></li>

              <?php if(@$_SESSION['giris']){ ?>
                <li class='kullanici'><a href="../blog_sitesi/panel/admingiris/cikis.php"><span>Çıkış Yap</span></a></li>
                <li class='kullanici'><a href="../blog_sitesi/panel/adminsayfasi/admin.php"><span>Cpanel</span></a></li>
                <?php }else{ ?>
                <li class='kullanici'><a href="../blog_sitesi/sayfalar/kullanici.php"><span>Giriş Yap</span></a></li>
                    <?php } ?>


            </ul>
        </div>

    </div>
    <div id="logo">
        <div id="sitelogo">
            <img src="galeri/Cool%20Text%20-%20--%20Kod%20%20%20%20Dnyam%20--%20%20(1).png">
        </div>
    </div>

    <div class="icarkaplan">
        <div id="icerik">
            <div class="icarkaplan">


                
                    <div class="icarkaplan">
                        <!-- ++++++++++++++++++++++++++++++++++++-->
                        <?php 
                        if(mysqli_num_rows($sonucsorgu)>0){
 while($sorguoku=mysqli_fetch_array($sonucsorgu)){ ?>
                        <a href="sayfalar/yonlendirme.php?icerik_id=<?php echo $sorguoku['icerik_id']; ?>">
                            <div class="div">






                                <!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->


                                <span>
                                    <h2 id="h2"><?php echo $sorguoku['icerik_baslik']; ?></h2>
                                </span><br>

                                <span id="yazi">
                                    <?php                                                               
echo $sorguoku['icerik_aciklama'];
?>
                                    <!-- ++++++++++++++++++++++++++++-->
                                </span>
                                <span id="yazi"><br><br>
                                    <?php                                                               
echo $sorguoku['icerik_detay'];
?>
                                    <!-- ++++++++++++++++++++++++++++-->
                                </span>

                            </div>
                        </a>
                        <?php } } else{?>
                        <div class="arama">
                     <div id="aramaerror" align="center"><?php 
                        echo     "<div class='a'>Aradığınız Bilgi Bulunmadı</div><br>";
                            echo     "<div class='b'>Öneriler</div><br>";
                           
                              echo     "<li class='c'>Tüm kelimeleri doğru yazdığınızdan emin olun</li><br>";
                             echo     "<li class='c'>Başka anahtar kelimeler deneyin</li><br>";
                            echo     "<li class='c'>Daha genel anahtar kelimeleri deneyin</li><br>";
                           
                         ?>
                      </div>  
                     <?php   } ?>

                        </div>

                        <div style="clear: both"></div>

                    </div>
                
            </div>
        </div>
    </div>

    <a class="yukaricik" href="#yukari"><img src="ikon/ikon.png"> </a>
