<?php session_start(); ?>
<div id="yukari"></div>
<a class="yukaricik" href="#yukari"><img src="../ikon/ikon.png" title="yukarı"> </a>
<br />


<div class="sosyal">
    <ul class="ikonlar">
        <li class="ikon" title="facebook"> <a href="http://www.facebook.com"><img src="../sosyal/facebook.png" /></a></li>
        <li class="ikon" title="twitter"><a href="http://www.twitter.com"><img src="../sosyal/twitter.png" /></a></li>
        <li class="ikon" title=" instagram"> <a href="http://www.instagram.com"><img src="../sosyal/instagram.png" /></a></li>
    </ul>
</div>
<div id="ustmenu">
    <div id='cssmenu'>
        <ul>
            <li class='ana' id="genislik"><a href="../index.php"><span>Ana Sayfa</span></a></li>

            <li class='acilir'><a href='#'><span>Kategoriler</span></a>

                <ul>

                     <li class='acmenu'><a href="../sayfalar/php.php"><span>PHP</span></a> </li>
                    <li class='acmenu'><a href="../sayfalar/html.php"><span>HTML</span></a> </li>
                    <li class='acmenu'><a href="../sayfalar/css.php"><span>CSS</span></a> </li>
                    <li class='acmenu'><a href="../sayfalar/csharp.php"><span>C#</span></a> </li>
                    <li class='acmenu'><a href="../sayfalar/java.php"><span>JAVA</span></a> </li>
                    <li class='acmenu'><a href="../sayfalar/python.php"><span>PYTHON</span></a> </li>
                    <li class='acmenu'><a href="../sayfalar/c++.php"><span>C++</span></a> </li>
                    <li class='acmenu'><a href="../sayfalar/javascript.php"><span>JAVASCRİPT</span></a> </li>
                    <li class='acmenu'><a href="../sayfalar/assembly.php"><span>ASSEMBLY</span></a> </li>

                </ul>

            </li>

            <li><a href="../sayfalar/hakkimizda.php"><span>Hakkımızda</span></a></li>
            <li><a href="../sayfalar/iletisim.php"><span>İletişim</span></a></li>
            <li><a href="../sayfalar/yazarlik.php"><span>Yazarlık</span></a></li>

            <?php if(@$_SESSION['giris']){ ?>
                <li class='kullanici'><a href="../../blog_sitesi/panel/admingiris/cikis.php"><span>Çıkış Yap</span></a></li>
                 <li class='kullanici'><a href="../panel/adminsayfasi/admin.php"><span>Cpanel</span></a></li>
                <?php }else{ ?>
                <li class='kullanici'><a href="../sayfalar/kullanici.php"><span>Giriş Yap</span></a></li>
                   
                    <?php } ?>
              


        </ul>
    </div>

</div>
