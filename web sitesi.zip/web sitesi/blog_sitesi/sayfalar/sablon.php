<!DOCTYPE html>
<meta charset="utf-8">
<html>

<head>
<title>Koddünyam | Sayfa</title>
    <link rel="stylesheet" href="../css/tasarim.css">
</head>

<body>
    <?php
        include "bolumler/ust.php";
    ?>

    <div class="icarkaplan">
        <div id="icerik">
            <!--- Burası Sayfa -->
        </div>
    </div>

    <a class="yukaricik" href="#yukari"><img src="../ikon/ikon.png"> </a>
