<!DOCTYPE html>
<meta charset="utf-8">
<html>

<head>
    <title>KULLANICI GİRİŞİ</title>
    <link rel="stylesheet" href="../css/kullanici.css">
</head>

<body>
   
    <?php
        include "bolumler/ust.php";
    ?>
    <div id="logo">
        <div id="sitelogo">
            <img src="../galeri/Cool%20Text%20-%20--%20Kod%20%20%20%20Dnyam%20--%20%20(1).png">
        </div>
    </div>

    <div class="icarkaplan">
        <div id="icerik">
            <div class="icarkaplan">
                <!-- ++++++++++++++++++++++++++++++++++++++-->

                <div class="giris">
                    <div id="girilogo" align="center">
                        <img src="../ikon/girislogo.png">
                    </div>

 
                    <?php include "../panel/admingiris/indeks.php" ?>
                
                </div>
                <div style="clear: both"></div>
                <!--  ++++++++++++++++++++++++++++++++++++++++++++++-->
                <div style="clear: both"></div>
            </div>
        </div>
    </div>


    <a class="yukaricik" href="#yukari"><img src="../ikon/ikon.png"> </a>
    </body></html>