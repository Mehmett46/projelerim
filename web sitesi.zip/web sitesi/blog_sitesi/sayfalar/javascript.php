<?php include "../php/baglanti.php";  ?>
<?php
$sql="Select * From icerik where icerik_kategori_id='8' ORDER BY icerik_id DESC ";
$kayitlar=mysqli_query($baglanti,$sql);
?>
<!DOCTYPE html>
<meta charset="utf-8">
<html>
<head>
<title>Koddünyam | JAVASCRİPT</title>
    <link rel="stylesheet" href="../css/tasarim.css">
</head>

<body>
      <div id="ara" align="center">
    <form action="../arama.php" id="kutu" method="get" style="display:inline; font-family: sans-serif;">
        <input id="" name="aramasorgusu" size="30" style="background:#; border: 1px solid #ff0606; font-weight: bold; font-size: 15px
; font-family: sans-serif;" ; type="text" placeholder="ne aramıştınız..." class="z" />
        <input id="buton" style="background: border: 1px;  font-weight: bold;" type="submit" value="ara" />
    </form>

</div>
    <?php
        include "bolumler/ust.php";
    ?>
    
<div id="logo">
    <div id="sitelogo">
        <img src="../galeri/javascriptlog.png">
    </div>
    
    
</div>
    <div class="icarkaplan">
        <div id="icerik">
            <!--- Burası JAVASCRİPT -->
             <div class="yerles" id="yerlesim">
                    <div class="icarkaplan">
                        <!-- ++++++++++++++++++++++++++++++++++++-->
                        <?php
                        while($kayit=mysqli_fetch_array($kayitlar)){ 
                        ?>
                         <a href="../sayfalar/yonlendirme.php?icerik_id=<?php echo $kayit['icerik_id']; ?>">
               <div class="div" title="devamını oku">

                            
                       

                           

                            <!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
                            
                            <div >
                            <span>
                                <h2 id="h2"><?php echo $kayit['icerik_baslik']; ?></h2>
                            </span>
                            <span id="yazi">
                                <?php                                                               
echo $kayit['icerik_aciklama'];
?>
                                <!-- ++++++++++++++++++++++++++++-->
                            </span>
                            <span id="yazi"><br><br>
                                <?php                                                               
echo $kayit['icerik_detay'];
?>
                                <!-- ++++++++++++++++++++++++++++-->
                            </span>
                            </div>
                        </div>
                        </a>
                            <?php } ?>
                <div style="clear: both"></div>
                    </div>
                      <!-- ++++++++++++++++++++++++++++++++++++-->
                </div>
            </div>
            
        </div>
    
    

    <a class="yukaricik" href="#yukari"><img src="../ikon/ikon.png"> </a>
