
<!DOCTYPE html>
<meta charset="utf-8">
<html>

<head>
<title>Koddünyam | Hakkımızda</title>
    <link rel="stylesheet" href="../css/hakkimizda.css">
</head>

<body>
      <div id="ara" align="center">
    <form action="../arama.php" id="kutu" method="get" style="display:inline; font-family: sans-serif;">
        <input id="" name="aramasorgusu" size="30" style="background:#; border: 1px solid #ff0606; font-weight: bold; font-size: 15px
; font-family: sans-serif;" ; type="text" placeholder="ne aramıştınız..." />
        <input id="buton" style="background: border: 1px;  font-weight: bold;" type="submit" value="ara" />
    </form>

</div>
    <?php
        include "bolumler/ust.php";
    ?>
 <div id="logo">
        <div id="sitelogo">
            <img src="../galeri/Cool%20Text%20-%20--%20Kod%20%20%20%20Dnyam%20--%20%20(1).png">
        </div>
    </div>

    <div class="icarkaplan">
        <div id="icerik">
            <!--- Burası Hakkımızda -->
         
        </div>
    </div>

    <a class="yukaricik" href="#yukari"><img src="../ikon/ikon.png"> </a>
