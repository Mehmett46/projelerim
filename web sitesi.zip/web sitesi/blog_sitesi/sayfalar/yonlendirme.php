<?php include "../php/baglanti.php";

session_start();
                        $icerik_id = $_GET['icerik_id'];

if(isset($_GET['yorum_id'])){
$silinecek_id=$_GET['yorum_id'];
$yorumsil=mysqli_query($baglanti, "DELETE FROM yorum WHERE yorum_id='$silinecek_id'");
if($yorumsil>0){
    header("Location: yonlendirme.php?icerik_id=$icerik_id");
    #echo "<br><span class='silindi'>başarıyla silindi</span>";
}
}else{}
?>


<!DOCTYPE html>
<meta charset="utf-8">
<html>

<head>
    <title>KOD DÜNYAM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/tasarim.css">
    <style>
        .ic {
            padding: 20px 10px 20px 25px;
        }

        .baslik {
            color: black;
            font-family: 'verdana', sans-serif;
            font-weight: bold;
            font-size: 25px;
        }

        .aciklama {
            font-size: 18px;
            font-family: sans-serif;
            color: green;
            font-style: italic;
        }

        .detay {
            font-size: 18px;
            font-family: sans-serif;
            margin-bottom: 30px;

        }

        .yorum {
            float: left;

            width: 900px;
            height: 100px;
            margin: 10px;
            background-color: #ffffff;
            border: #1bff35 solid 1px;
            border-radius: 8px;
            margin-right: auto;
            margin-left: auto;
            margin: 10px;
            padding: 9px;
            box-shadow: inset 0px 0px 20px #000;
            -webkit-box-shadow: inset 0 0 20px #000;
            overflow: hidden;
            background-size: cover;


        }

        .yorumgir {
            float: left;

            width: 900px;
            height: 140px;
            margin: 10px;
            background-color: #ffffff;
            border: #1bff35 solid 1px;
            border-radius: 8px;
            margin-right: auto;
            margin-left: auto;
            margin: 10px;
            padding: 9px;
            box-shadow: inset 0px 0px 20px #000;
            -webkit-box-shadow: inset 0 0 20px #000;
            overflow: hidden;
            background-size: cover;


        }

        .yorumbaslik {
            font-family: sans-serif;
            font-size: 25px;
            font-weight: bold;
            margin-left: 340px;
            color: blue;

        }

        .yor {
            width: 300px;
            height: 70px;
            font-family: sans-serif;
            font-weight: bold;
            border: 2px solid red;
            border-radius: 4px;
            margin-bottom: 6px;
            margin-left: 115px;
        }

        input[type=text] {
            border: 2px solid red;
            border-radius: 4px;
            margin-bottom: 6px;
            width: 300px;
        }

        .j{
            border: 2px solid red;
            border-radius: 4px;
            margin-bottom: 6px;
            font-weight: bold;
            margin-left: 115px;
        }

        .uye {
            font-size: 18px;
            font-weight: bold;
            font-family: sans-serif;
        }

        h1 {
            color: green;
        }

        .s {
            margin-left: auto;
            margin-right: auto;
            float: right;
            font-family: sans-serif;
            padding: 14px;
            font-size: 15px;
            font-weight: bold;

        }

        .s a:hover {
            color: green;
        }

        .l {
            text-decoration: none;
        }

        .degis {
            color: red;
            margin-left: auto;
            margin-right: auto;
            float: left;
            font-family: sans-serif;
            padding: 18px;
            font-size: 13px;
            font-weight: bold;
        }

        .silindi {
            margin-left: 16px;
        }

        .y {
            color: green;
            font-size: 15px;
            font-weight: bold;
        }
        .i{
            font-family: sans-serif;
            font-size: 14px;
            font-weight: 550;
        }
        .x{
            font-size: 50px;
            color: red;
        }
    </style>
</head>


<body>
    <div id="yukari"></div>
    <a class="yukaricik" href="#yukari"><img src="../ikon/ikon.png" title="yukarı"> </a>
    <br />

    <div id="ara" align="center">
        <form action="../arama.php" id="kutu" method="get" style="display:inline; font-family: sans-serif;">
            <input id="" name="aramasorgusu" size="30" style="background:#; border: 1px solid #ff0606; font-weight: bold; font-size: 15px
; font-family: sans-serif;" ; type="text" placeholder="ne aramıştınız..." />
            <input id="buton" style="background: border: 1px;  font-weight: bold;" type="submit" value="ara" />
        </form>

    </div>
    <div class="sosyal">
        <ul class="ikonlar">
            <li class="ikon" title="facebook"> <a href="http://www.facebook.com"><img src="../sosyal/facebook.png" /></a></li>
            <li class="ikon" title="twitter"><a href="http://www.twitter.com"><img src="../sosyal/twitter.png" /></a></li>
            <li class="ikon" title=" instagram"> <a href="http://www.instagram.com"><img src="../sosyal/instagram.png" /></a></li>
        </ul>
    </div>
    <div id="ustmenu">
        <div id='cssmenu'>
            <ul>
                <li class='ana' id="genislik"><a href="../index.php"><span>Ana Sayfa</span></a></li>

                <li class='acilir'><a href='#'><span>Kategoriler</span></a>

                    <ul>

                        <li class='acmenu'><a href="../sayfalar/php.php"><span>PHP</span></a> </li>
                        <li class='acmenu'><a href="../sayfalar/html.php"><span>HTML</span></a> </li>
                        <li class='acmenu'><a href="../sayfalar/css.php"><span>CSS</span></a> </li>
                        <li class='acmenu'><a href="../sayfalar/csharp.php"><span>C#</span></a> </li>
                        <li class='acmenu'><a href="../sayfalar/java.php"><span>JAVA</span></a> </li>
                        <li class='acmenu'><a href="../sayfalar/python.php"><span>PYTHON</span></a> </li>
                        <li class='acmenu'><a href="../sayfalar/c++.php"><span>C++</span></a> </li>
                        <li class='acmenu'><a href="../sayfalar/javascript.php"><span>JAVASCRİPT</span></a> </li>
                        <li class='acmenu'><a href="../sayfalar/assembly.php"><span>ASSEMBLY</span></a> </li>

                    </ul>

                </li>

                <li><a href="../sayfalar/hakkimizda.php"><span>Hakkımızda</span></a></li>
                <li><a href="../sayfalar/iletisim.php"><span>İletişim</span></a></li>
                <li><a href="../sayfalar/yazarlik.php"><span>Yazarlık</span></a></li>
<?php if(@$_SESSION['giris']){ ?>
                <li class='kullanici'><a href="../../blog_sitesi/panel/admingiris/cikis.php"><span>Çıkış Yap</span></a></li>
                <li class='kullanici'><a href="../panel/adminsayfasi/admin.php"><span>Cpanel</span></a></li>
                <?php }else{ ?>
                <li class='kullanici'><a href="../sayfalar/kullanici.php"><span>Giriş Yap</span></a></li>
                    <?php } ?>
              

            </ul>
        </div>

    </div>
    <div id="logo">
        <div id="sitelogo">
            <img src="../galeri/Cool%20Text%20-%20--%20Kod%20%20%20%20Dnyam%20--%20%20(1).png">
        </div>
    </div>

    <div class="icarkaplan">
        <div id="icerik">
            <div class="icarkaplan">


                <div class="yerles" id="yerlesim">

                    <div class="ic">
                        <!-- ++++++++++++++++++++++++++++++++++++-->

                        <?php
$p=mysqli_query($baglanti, "select * from resim WHERE icerik_resim_id=".(int)$_GET['icerik_id']);
                      

                    $m=@mysqli_num_rows($p);
                             if($m>0){ 
                      
                        $sql="SELECT * FROM icerik INNER JOIN resim ON icerik.icerik_id = resim.icerik_resim_id   WHERE icerik.icerik_id=".(int)$_GET['icerik_id'];
                        
                        $kayitlar = mysqli_query($baglanti, $sql);
                        $getir = mysqli_fetch_array($kayitlar);  ?>
                        <img src="<?php echo $getir['resim_link']; ?>">
                        <div class="baslik" align="center"> <?php echo $getir['icerik_baslik'];  ?></div><br><br>
                        <div class="aciklama"> <?php echo $getir['icerik_aciklama']; ?></div><br>
                        <div class="detay"> <?php echo $getir['icerik_detay']; ?></div>
                        <?php }else{
                                $sql="SELECT * FROM icerik    WHERE icerik.icerik_id=".(int)$_GET['icerik_id'];
                        
                        $kayitlar = mysqli_query($baglanti, $sql);
                        $getir = mysqli_fetch_array($kayitlar);  ?>
                       
                        <div class="baslik" align="center"> <?php echo $getir['icerik_baslik'];  ?></div><br><br>
                        <div class="aciklama"> <?php echo $getir['icerik_aciklama']; ?></div><br>
                        <div class="detay"> <?php echo $getir['icerik_detay']; ?></div> 
                          <?php   } ?>
                        
                        <span class="yorumbaslik">YORUMLAR</span>
                        <?php 
       
    if (isset($_SESSION['giris'])) {
     
                        ?>
                        <div class="yorumgir">

                            <form action="" method="post" class="uye">
                                Kullanıcı Adı:<input type="text" name="uye_adsoyad" placeholder="üye ad soyad..."><br>
                                <textarea name="yorum_icerik" class="yor" placeholder="yorum yaz..."></textarea><br>
                                <input type="submit" value="gönder" name="yorum" class="j">
                            </form>

                            <?php

             
               
                     
if(@$_POST["yorum"])
{    $uye_id=$_SESSION['giris']['uye_id']; 
	$uye_adsoyad=$_POST["uye_adsoyad"];
	$yorum_icerik=$_POST["yorum_icerik"];
   if($uye_adsoyad<>"" && $yorum_icerik<>""){
        $baglanti->query("INSERT INTO yorum (uye_adsoyad, yorum_icerik_id, yorum_icerik, yorum_uye_id)values('$uye_adsoyad', '$icerik_id','$yorum_icerik', '$uye_id')");
        
        if($baglanti){
             
            echo " yorumun eklendi ".$_SESSION['giris']['uye_kullanici'].""; 
       
        }
        else{
            echo "yorum eklenemedi";
        }
   }else{}
}
    
 
	                  
 ?>
                            <?php }else{
        echo "<br><h1>yorum yapabilmeniz için giriş yapmanız gerekiyor</h1>";
    } ?>


                            <div style="clear: both"></div>
                        </div>
                        <?php

                        ?>
                         <?php 
                            
 $kayitlar=mysqli_query($baglanti, "select * from yorum  where yorum_icerik_id='$icerik_id' order by yorum_id desc");
                           
                            $say=@mysqli_num_rows($kayitlar);
                           if($say>0 || !isset($_SESSION['giris'])){
                            ?>
                        <h2>(<?=$say ?>)yorum var</h2>
                        <?php }elseif($say==0 || isset($_SESSION['giris'])){ 
                             echo  "<h1>Henüz yorum eklenmemiş ilk yorumu yapan sen ol ".$_SESSION['giris']['uye_kullanici']."</h1>";
                            
                             } while($kayit=mysqli_fetch_array($kayitlar)){ ?>
                        <div class="yorum">

                            <div class='p'><span class="y">Kullanıcı adı:</span><span class="i"><?php echo $kayit['uye_adsoyad']; ?></span></div><br>
                             <div clas='p'><span class="y">Yorumu:</span><span class="i"><?php echo $kayit['yorum_icerik']; ?></span></div>
                            <div clas='p'><span class="y">yorum tarihi:</span><span class="i"><?php echo $kayit['yorum_tarih']; ?></span></div>

                            <?php
                            if($kayit['yorum_degistirme']==1){ 
                                
                                
                                 echo "<span class='degis'>[değiştirildi]</span>"; }else{}
                                    @$uye_id=$_SESSION['giris']['uye_id']; 
                                   @$kontrol=$_SESSION['giris']['uye_yetki'];
                                   if(@$_SESSION['giris'] and $uye_id==$kayit['yorum_uye_id'] or $kontrol==1){                                       
                                 ?>

                            <div class="s"><a href="yonlendirme.php?icerik_id=<?php echo $_GET['icerik_id']; ?>&yorum_id=<?php  echo $kayit['yorum_id'];  ?>" class="l">sil</a></div>
                          <?php if(@$_SESSION['giris'] and $uye_id!=$kayit['yorum_uye_id'] and $kontrol==1 ){}else{?>
                            <div class="s"><a href="../panel/adminislemleri/yorumduzelt.php?icerik_id=<?php echo $_GET['icerik_id']; ?>&yorum_id=<?php echo $kayit['yorum_id']; ?>" class="l">düzenle</a></div>
                            <?php }} ?>
                        </div>
                        <?php } ?>


                        <div style="clear:both"></div>

                    </div>

                </div>
            </div>
        </div>

        <a class="yukaricik" href="#yukari"><img src="../ikon/ikon.png"> </a>
